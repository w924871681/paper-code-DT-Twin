# CUDA frozen main-evaluation replay archive

The public bootstrap was verified and staged, all seven frozen methods ran on CUDA, the locked analysis and formal audit passed, and all non-timing outputs matched the historical frozen run. Source-initialization training was not repeated.

The replay ledger records environment-dependent per-case wall-clock fields. The manuscript runtime table is produced by a separate five-repeat, GPU-synchronized timing protocol. These values are not expected to be numerically identical. Online runtime fields are retained for transparency, but excluded from the exact non-timing comparison.

- Ledger: `PASS_FROZEN_MAIN_EVALUATION_REPLAY`
- Formal audit: `PASS_C33_LOCKED_EVALUATION_COMPLETE_AND_AUDITED`
- Historical comparison: `PASS_HISTORICAL_OUTPUT_COMPARISON`
