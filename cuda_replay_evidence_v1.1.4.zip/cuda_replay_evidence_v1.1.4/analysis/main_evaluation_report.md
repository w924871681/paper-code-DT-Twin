# C3 Locked End-to-End External Comparison

This pool is evaluation-only. No method or selector retuning is allowed.

| Method | Feasible | MSE | MAE | Worst-10% | CVaR90 | Online s | Params | FLOPs |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| ours_c32_locked | 100.0% | 0.00421929 | 0.04866258 | 0.01575516 | 0.01170621 | 11.100 | 14892.5 | 751433.2 |
| pt_ft | 100.0% | 0.00512042 | 0.05382032 | 0.01907765 | 0.01387362 | 0.267 | 5746.5 | 1050784.0 |
| medet_style | 100.0% | 0.00711503 | 0.06408772 | 0.02417004 | 0.02239821 | 0.303 | 5746.5 | 1050784.0 |
| scratch50 | 100.0% | 0.02620176 | 0.12561986 | 0.07329844 | 0.08687933 | 0.289 | 5746.5 | 1050784.0 |
| meta_nas_lite | 100.0% | 0.00710510 | 0.06427556 | 0.02650084 | 0.01908874 | 19.449 | 30995.3 | 1468894.4 |
| zero_nas | 100.0% | 0.03038667 | 0.13499794 | 0.07519219 | 0.11063407 | 1.694 | 86485.3 | 481058.4 |
| zero_nas_ft | 100.0% | 0.00752716 | 0.06654438 | 0.02853947 | 0.01878070 | 39.034 | 62075.9 | 1571621.4 |

## Paired Ours comparisons

- Ours vs pt_ft: N=80, MSE win=0.713, gain=14.602% (95% CI 9.408%, 20.144%).
- Ours vs medet_style: N=80, MSE win=0.875, gain=35.372% (95% CI 25.392%, 44.263%).
- Ours vs scratch50: N=80, MSE win=1.000, gain=80.712% (95% CI 78.066%, 83.215%).
- Ours vs meta_nas_lite: N=80, MSE win=0.950, gain=40.401% (95% CI 32.653%, 47.577%).
- Ours vs zero_nas: N=80, MSE win=1.000, gain=76.294% (95% CI 68.952%, 82.648%).
- Ours vs zero_nas_ft: N=80, MSE win=0.988, gain=45.029% (95% CI 36.531%, 52.552%).
